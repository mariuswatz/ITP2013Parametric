package unlekker.mb2.externals;

import unlekker.mb2.util.UMB;

public class UToxi extends UMB {

}
